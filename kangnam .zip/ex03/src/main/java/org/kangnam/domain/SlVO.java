package org.kangnam.domain;

public class SlVO
{
	private String sl_prod_nm, sl_mn;

	public String getSl_prod_nm()
	{
		return sl_prod_nm;
	}

	public void setSl_prod_nm(String sl_prod_nm)
	{
		this.sl_prod_nm = sl_prod_nm;
	}

	public String getSl_mn()
	{
		return sl_mn;
	}

	public void setSl_mn(String sl_mn)
	{
		this.sl_mn = sl_mn;
	}






}
