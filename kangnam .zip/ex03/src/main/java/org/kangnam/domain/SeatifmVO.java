package org.kangnam.domain;

public class SeatifmVO
{
	private String seat_sq, seat_aloc_sq, seat_nm, mem_nm, seat_aloc_strt_tm, mon_mem_end_dd;


	public String getSeat_aloc_sq()
	{
		return seat_aloc_sq;
	}

	public void setSeat_aloc_sq(String seat_aloc_sq)
	{
		this.seat_aloc_sq = seat_aloc_sq;
	}

	public String getSeat_sq()
	{
		return seat_sq;
	}

	public void setSeat_sq(String seat_sq)
	{
		this.seat_sq = seat_sq;
	}

	public String getSeat_nm()
	{
		return seat_nm;
	}

	public void setSeat_nm(String seat_nm)
	{
		this.seat_nm = seat_nm;
	}

	public String getMem_nm()
	{
		return mem_nm;
	}

	public void setMem_nm(String mem_nm)
	{
		this.mem_nm = mem_nm;
	}

	public String getSeat_aloc_strt_tm()
	{
		return seat_aloc_strt_tm;
	}

	public void setSeat_aloc_strt_tm(String seat_aloc_strt_tm)
	{
		this.seat_aloc_strt_tm = seat_aloc_strt_tm;
	}

	public String getMon_mem_end_dd()
	{
		return mon_mem_end_dd;
	}

	public void setMon_mem_end_dd(String mon_mem_end_dd)
	{
		this.mon_mem_end_dd = mon_mem_end_dd;
	}



}